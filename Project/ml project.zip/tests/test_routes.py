import pytest
import os
import sys

# Add parent directory to path so app can be imported
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import app
from db import init_db, clear_all_patient_records, get_patient_stats, get_all_patient_records

@pytest.fixture
def client():
    app.config['TESTING'] = True
    init_db()
    with app.test_client() as client:
        yield client

def test_home_page_and_live_stats(client):
    """Test Home page renders with branding, live stats cards, and disclaimer"""
    response = client.get('/')
    assert response.status_code == 200
    assert b"MediMind" in response.data
    assert b"Smarter Insights. Better Health." in response.data
    assert b"Start Prediction" in response.data
    assert b"Patient Records" in response.data
    assert b"Total Patients" in response.data
    assert b"Diabetes Predicted" in response.data
    assert b"Diabetes Not Predicted" in response.data
    # Strict restriction: No student or team names
    assert b"Uttej" not in response.data
    assert b"Hitesh" not in response.data
    assert b"Sudheer" not in response.data
    assert b"Team Members" not in response.data
    assert b"Roll Number" not in response.data

def test_predict_form_has_patient_details_and_7_medical_tests(client):
    """Test form has Patient ID, Patient Name, Age at the top, followed by the 7 medical tests"""
    response = client.get('/predict')
    assert response.status_code == 200

    # Fields at the top of the form
    assert b"Patient ID" in response.data
    assert b"Auto-generated" in response.data
    assert b"Patient Name" in response.data
    assert b"Age" in response.data

    # 7 Medical Test Fields
    assert b"Fasting Blood Glucose (FPG)" in response.data
    assert b"Glycated Hemoglobin (HbA1c)" in response.data
    assert b"2-Hour OGTT Glucose" in response.data
    assert b"Random Blood Glucose (RPG)" in response.data
    assert b"Fasting Plasma Insulin" in response.data
    assert b"Total Cholesterol" in response.data
    assert b"Triglycerides" in response.data

    # Required buttons
    assert b"Predict Diabetes" in response.data
    assert b"Reset Form" in response.data
    assert b"Back to Home" in response.data

def test_validation_requires_patient_name_and_age(client):
    """Test Patient Name and Age are required fields"""
    clear_all_patient_records()
    assert get_patient_stats()['total'] == 0

    # 1. Missing Patient Name
    res1 = client.post('/predict', data={
        'patient_name': '',
        'age': '45',
        'fpg': '100'
    })
    assert res1.status_code == 400
    assert b"Patient Name is required" in res1.data

    # 2. Missing Age
    res2 = client.post('/predict', data={
        'patient_name': 'Eleanor Vance',
        'age': '',
        'fpg': '100'
    })
    assert res2.status_code == 400
    assert b"Age is required" in res2.data

    # 3. Invalid Age
    res3 = client.post('/predict', data={
        'patient_name': 'Eleanor Vance',
        'age': '150',
        'fpg': '100'
    })
    assert res3.status_code == 400
    assert b"valid Age between 1 and 120" in res3.data

    # 4. Valid Name & Age, but all 7 tests blank
    res4 = client.post('/predict', data={
        'patient_name': 'Eleanor Vance',
        'age': '35',
        'fpg': '', 'hba1c': '', 'ogtt': '', 'rpg': '', 'insulin': '', 'cholesterol': '', 'triglycerides': ''
    })
    assert res4.status_code == 400
    assert b"Please enter at least one medical test result" in res4.data

    # Nothing saved to database
    assert get_patient_stats()['total'] == 0

def test_prediction_saves_patient_details_and_test_results(client):
    """Test full prediction flow saves Patient Name, Age, and test results to SQLite"""
    clear_all_patient_records()

    # Low-Risk Patient
    res1 = client.post('/predict', data={
        'patient_id': 'PID-TEST01',
        'patient_name': 'Clara Oswald',
        'age': '29',
        'fpg': '85'
    }, follow_redirects=True)
    assert res1.status_code == 200
    assert b"Clara Oswald" in res1.data
    assert b"29 Years" in res1.data
    assert b"PID-TEST01" in res1.data
    assert b"Diabetes Not Predicted" in res1.data

    # High-Risk Patient
    res2 = client.post('/predict', data={
        'patient_id': 'PID-TEST02',
        'patient_name': 'Arthur Dent',
        'age': '56',
        'hba1c': '9.4',
        'cholesterol': '265'
    }, follow_redirects=True)
    assert res2.status_code == 200
    assert b"Arthur Dent" in res2.data
    assert b"56 Years" in res2.data
    assert b"PID-TEST02" in res2.data
    assert b"Diabetes Predicted" in res2.data

    # Database records verification
    recs = get_all_patient_records()
    assert len(recs) == 2
    clara = [r for r in recs if r['patient_name'] == 'Clara Oswald'][0]
    assert int(clara['age']) == 29
    assert clara['fpg'] == 85.0

def test_records_page_export_and_report_show_patient_details(client):
    """Test Patient Name and Age appear in Patient Records table, CSV export, and printable report"""
    records_res = client.get('/records')
    assert records_res.status_code == 200
    assert b"Clara Oswald" in records_res.data
    assert b"Arthur Dent" in records_res.data
    assert b"29 yrs" in records_res.data
    assert b"56 yrs" in records_res.data

    # CSV Export
    csv_res = client.get('/records/export')
    assert csv_res.status_code == 200
    assert csv_res.content_type == 'text/csv; charset=utf-8'
    assert b"Patient Name" in csv_res.data
    assert b"Age" in csv_res.data
    assert b"Clara Oswald" in csv_res.data
    assert b"Arthur Dent" in csv_res.data

    # Printable Report
    all_recs = get_all_patient_records()
    clara_id = [r['id'] for r in all_recs if r['patient_name'] == 'Clara Oswald'][0]
    report_res = client.get(f'/patient/{clara_id}')
    assert report_res.status_code == 200
    assert b"Clara Oswald" in report_res.data
    assert b"29 Years" in report_res.data
    assert b"PID-TEST01" in report_res.data
