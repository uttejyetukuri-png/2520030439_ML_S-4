# MediMind Data Directory

This folder is reserved for the clinical dataset used to train and evaluate the Multinomial Logistic Regression model.

### Guidelines:
- Place the labelled CSV or dataset file here (e.g., `dataset.csv`).
- Ensure no personal identifiers (names, IDs, phone numbers) are present in the clinical records.
- When the dataset is provided, `train_model.py` will read from this directory to split, preprocess, train, and evaluate the model.
