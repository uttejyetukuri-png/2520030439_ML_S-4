/**
 * MediMind — Smarter Insights. Better Health.
 * Patient Details & 7 Medical Tests Prediction Form Scripts
 */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('patient-form');
  const resetBtn = document.getElementById('btn-reset-form');
  const loadingBox = document.getElementById('prediction-loading');
  const clientAlert = document.getElementById('client-error-alert');
  const clientAlertText = document.getElementById('client-error-text');

  // 1. Reset Form Button Handler
  if (resetBtn && form) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      const inputs = form.querySelectorAll('input:not([type="hidden"])');
      inputs.forEach(input => {
        if (input.id !== 'display_patient_id') {
          input.value = '';
        }
        input.classList.remove('is-invalid');
      });

      if (clientAlert) clientAlert.classList.add('d-none');
      const serverAlert = document.getElementById('server-error-alert');
      if (serverAlert) serverAlert.classList.add('d-none');

      const nameInput = document.getElementById('patient_name');
      if (nameInput) nameInput.focus();
    });
  }

  // 2. Form Submit Validation
  if (form) {
    form.addEventListener('submit', (e) => {
      const nameInput = document.getElementById('patient_name');
      const ageInput = document.getElementById('age');

      const fpgInput = document.getElementById('fpg');
      const hba1cInput = document.getElementById('hba1c');
      const ogttInput = document.getElementById('ogtt');
      const rpgInput = document.getElementById('rpg');
      const insulinInput = document.getElementById('insulin');
      const cholInput = document.getElementById('cholesterol');
      const tgInput = document.getElementById('triglycerides');

      let isValid = true;
      let firstInvalid = null;
      let customError = '';

      // 1. Validate Patient Name (Required)
      if (!nameInput || nameInput.value.trim() === '') {
        isValid = false;
        if (nameInput) nameInput.classList.add('is-invalid');
        firstInvalid = firstInvalid || nameInput;
        customError = customError || 'Patient Name is required.';
      } else {
        nameInput.classList.remove('is-invalid');
      }

      // 2. Validate Age (Required, 1-120)
      const ageVal = parseFloat(ageInput ? ageInput.value.trim() : '');
      if (isNaN(ageVal) || ageVal <= 0 || ageVal > 120) {
        isValid = false;
        if (ageInput) ageInput.classList.add('is-invalid');
        firstInvalid = firstInvalid || ageInput;
        customError = customError || 'Please provide a valid Age between 1 and 120 years.';
      } else {
        if (ageInput) ageInput.classList.remove('is-invalid');
      }

      // 3. Validate Medical Tests
      const testInputs = [
        { input: fpgInput, min: 40, max: 500, label: 'Fasting Blood Glucose (40–500 mg/dL)' },
        { input: hba1cInput, min: 3.0, max: 18.0, label: 'Glycated Hemoglobin (3–18%)' },
        { input: ogttInput, min: 40, max: 500, label: '2-Hour OGTT Glucose (40–500 mg/dL)' },
        { input: rpgInput, min: 40, max: 500, label: 'Random Blood Glucose (40–500 mg/dL)' },
        { input: insulinInput, min: 1.0, max: 500, label: 'Fasting Plasma Insulin (1–500 µIU/mL)' },
        { input: cholInput, min: 50, max: 500, label: 'Total Cholesterol (50–500 mg/dL)' },
        { input: tgInput, min: 30, max: 1500, label: 'Triglycerides (30–1500 mg/dL)' }
      ];

      let anyEntered = false;

      for (const item of testInputs) {
        if (!item.input) continue;
        const valStr = item.input.value.trim();
        if (valStr !== '') {
          anyEntered = true;
          const valNum = parseFloat(valStr);
          if (isNaN(valNum) || valNum < item.min || valNum > item.max) {
            item.input.classList.add('is-invalid');
            isValid = false;
            firstInvalid = firstInvalid || item.input;
            customError = customError || `Please enter a valid value for ${item.label}.`;
          } else {
            item.input.classList.remove('is-invalid');
          }
        } else {
          item.input.classList.remove('is-invalid');
        }
      }

      // Check that at least one medical test is filled
      if (!anyEntered) {
        isValid = false;
        customError = customError || 'Please enter at least one medical test result to predict diabetes.';
        firstInvalid = firstInvalid || fpgInput;
      }

      if (!isValid) {
        e.preventDefault();
        if (clientAlert) {
          clientAlertText.textContent = customError;
          clientAlert.classList.remove('d-none');
        }
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      // Show loading spinner on valid submission
      if (loadingBox) {
        loadingBox.style.display = 'block';
        const submitBtn = document.getElementById('btn-predict');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Evaluating...';
        }
      }
    });
  }
});
