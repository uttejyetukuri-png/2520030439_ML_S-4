"""
MediMind — Smarter Insights. Better Health.
7-Field Medical Test Diabetes Prediction & Patient Records System
"""

import os
import io
import csv
import random
import string
import joblib
import pandas as pd
import numpy as np
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, Response
from dotenv import load_dotenv

from db import (
    init_db,
    save_patient_record,
    get_patient_record,
    get_patient_stats,
    get_all_patient_records,
    delete_patient_record
)

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'medimind-super-secret-key-educational-2026')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')
MODEL_SUITE_PATH = os.path.join(MODELS_DIR, 'diabetes_model_suite.joblib')

# Initialize SQLite database on startup
init_db()

def load_model_suite():
    """Load the trained sub-model suite."""
    if os.path.exists(MODEL_SUITE_PATH):
        try:
            return joblib.load(MODEL_SUITE_PATH)
        except Exception as e:
            app.logger.error(f"Error loading model suite: {e}")
    return None

def generate_patient_id():
    """Generate a clean, unique patient ID (e.g. PID-74291)."""
    random_digits = ''.join(random.choices(string.digits, k=5))
    return f"PID-{random_digits}"

def evaluate_patient_prediction(fpg, hba1c, ogtt, rpg, insulin, cholesterol, triglycerides, model_suite):
    """
    Dynamically select and evaluate trained sub-models based on the exact tests provided.
    Never invents or imputes values for tests not taken.
    """
    tests_present = [x for x in [fpg, hba1c, ogtt, rpg, insulin, cholesterol, triglycerides] if x is not None]
    if not tests_present:
        return {
            'status': 'insufficient',
            'error_message': "Please enter at least one medical test result to evaluate diabetes risk."
        }

    submodels_to_run = []

    # 1. Glycated Hemoglobin & Fasting Blood Glucose
    if hba1c is not None and fpg is not None:
        submodels_to_run.append(('hba1c_fpg', {'hba1c': hba1c, 'fpg': fpg}, 1.0, "Dual HbA1c & Fasting Glucose"))
    elif hba1c is not None:
        submodels_to_run.append(('hba1c', {'hba1c': hba1c}, 0.95, "Glycated Hemoglobin (HbA1c)"))
    elif fpg is not None:
        submodels_to_run.append(('fpg', {'fpg': fpg}, 0.90, "Fasting Blood Glucose (FPG)"))

    # 2. 2-Hour OGTT Glucose & Insulin
    if ogtt is not None and insulin is not None:
        submodels_to_run.append(('ogtt_insulin', {'ogtt': ogtt, 'insulin': insulin}, 0.90, "OGTT & Plasma Insulin Dual Model"))
    elif ogtt is not None:
        submodels_to_run.append(('ogtt', {'ogtt': ogtt}, 0.85, "2-Hour OGTT Glucose Challenge"))
    elif insulin is not None:
        submodels_to_run.append(('insulin', {'insulin': insulin}, 0.80, "Fasting Plasma Insulin"))

    # 3. Random Blood Glucose (RPG)
    if rpg is not None:
        submodels_to_run.append(('rpg', {'rpg': rpg}, 0.75, "Random Blood Glucose (RPG)"))

    # 4. Total Cholesterol & Triglycerides (Lipids)
    if cholesterol is not None and triglycerides is not None:
        submodels_to_run.append(('lipids', {'cholesterol': cholesterol, 'triglycerides': triglycerides}, 0.75, "Lipid Profile (Cholesterol & Triglycerides)"))
    elif cholesterol is not None:
        submodels_to_run.append(('cholesterol', {'cholesterol': cholesterol}, 0.70, "Total Cholesterol"))
    elif triglycerides is not None:
        submodels_to_run.append(('triglycerides', {'triglycerides': triglycerides}, 0.70, "Serum Triglycerides"))

    if not submodels_to_run:
        return {'status': 'insufficient', 'error_message': "No matching model available for provided tests."}

    total_weighted_prob = 0.0
    total_weights = 0.0
    evaluated_details = []

    for model_key, feat_dict, weight, label in submodels_to_run:
        sub = model_suite.get(model_key)
        if not sub:
            continue
        pipeline = sub['pipeline']
        expected_cols = sub['features']
        df_in = pd.DataFrame([feat_dict])[expected_cols]
        prob_pos = float(pipeline.predict_proba(df_in)[0][1])

        total_weighted_prob += (prob_pos * weight)
        total_weights += weight
        evaluated_details.append({
            'model_key': model_key,
            'label': label,
            'probability': round(prob_pos * 100, 2),
            'features': expected_cols
        })

    if total_weights == 0.0:
        return {'status': 'insufficient', 'error_message': "Prediction calculation failed."}

    final_prob_pos = total_weighted_prob / total_weights
    prob_diabetes = round(final_prob_pos * 100, 2)
    prob_no_diabetes = round((1.0 - final_prob_pos) * 100, 2)

    is_diabetes = (prob_diabetes >= 50.0)
    prediction_text = "Diabetes Predicted" if is_diabetes else "Diabetes Not Predicted"

    # Human-readable summary of evaluated tests
    summary_parts = []
    if fpg is not None: summary_parts.append(f"FPG: {fpg} mg/dL")
    if hba1c is not None: summary_parts.append(f"HbA1c: {hba1c}%")
    if ogtt is not None: summary_parts.append(f"OGTT: {ogtt} mg/dL")
    if rpg is not None: summary_parts.append(f"RPG: {rpg} mg/dL")
    if insulin is not None: summary_parts.append(f"Insulin: {insulin} µIU/mL")
    if cholesterol is not None: summary_parts.append(f"Cholesterol: {cholesterol} mg/dL")
    if triglycerides is not None: summary_parts.append(f"Triglycerides: {triglycerides} mg/dL")

    return {
        'status': 'success',
        'is_diabetes': is_diabetes,
        'prediction': prediction_text,
        'prob_diabetes': prob_diabetes,
        'prob_no_diabetes': prob_no_diabetes,
        'evaluated_tests': ", ".join(summary_parts),
        'evaluated_models': evaluated_details
    }

# -----------------------------------------------------------------------------
# Web Page Routes
# -----------------------------------------------------------------------------

@app.route('/')
def home():
    """Page 1: Home Page with Live Database Statistics"""
    stats = get_patient_stats()
    return render_template('index.html', active_page='home', stats=stats)

@app.route('/predict', methods=['GET'])
def predict():
    """Page 2: 7-Field Medical Test Prediction Form in 2-Column Grid"""
    patient_id = request.args.get('patient_id') or generate_patient_id()
    return render_template(
        'predict.html',
        active_page='predict',
        patient_id=patient_id,
        form_data={}
    )

@app.route('/predict', methods=['POST'])
def handle_predict():
    """Validate 7 medical tests, run exact-feature models, save to SQLite, and redirect."""
    model_suite = load_model_suite()
    form_data = request.form.to_dict()
    patient_id = form_data.get('patient_id', '').strip() or generate_patient_id()

    if not model_suite:
        return render_template(
            'predict.html',
            active_page='predict',
            patient_id=patient_id,
            form_data=form_data,
            error_message="Model artifacts not found. Please run 'python train_model.py'."
        ), 500

    # 1. Validate Required Patient Details (Patient Name and Age)
    patient_name = form_data.get('patient_name', '').strip()
    if not patient_name:
        return render_template(
            'predict.html',
            active_page='predict',
            patient_id=patient_id,
            form_data=form_data,
            error_message="Patient Name is required."
        ), 400

    age_val = form_data.get('age', '').strip()
    if not age_val:
        return render_template(
            'predict.html',
            active_page='predict',
            patient_id=patient_id,
            form_data=form_data,
            error_message="Age is required."
        ), 400
    try:
        age = float(age_val)
        if age <= 0 or age > 120:
            raise ValueError
    except ValueError:
        return render_template(
            'predict.html',
            active_page='predict',
            patient_id=patient_id,
            form_data=form_data,
            error_message="Please enter a valid Age between 1 and 120 years."
        ), 400

    def parse_optional_float(field_name, min_val, max_val, error_label):
        val_str = form_data.get(field_name, '').strip()
        if not val_str:
            return None, None
        try:
            val = float(val_str)
            if val < min_val or val > max_val:
                return None, f"Please enter a valid {error_label} between {min_val} and {max_val}."
            return val, None
        except ValueError:
            return None, f"Please enter a valid numeric value for {error_label}."

    # Parse and validate the 7 medical tests
    fpg, err = parse_optional_float('fpg', 40.0, 500.0, "Fasting Blood Glucose (FPG)")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    hba1c, err = parse_optional_float('hba1c', 3.0, 18.0, "Glycated Hemoglobin (HbA1c)")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    ogtt, err = parse_optional_float('ogtt', 40.0, 500.0, "2-Hour OGTT Glucose")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    rpg, err = parse_optional_float('rpg', 40.0, 500.0, "Random Blood Glucose (RPG)")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    insulin, err = parse_optional_float('insulin', 1.0, 500.0, "Fasting Plasma Insulin")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    cholesterol, err = parse_optional_float('cholesterol', 50.0, 500.0, "Total Cholesterol")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    triglycerides, err = parse_optional_float('triglycerides', 30.0, 1500.0, "Triglycerides")
    if err: return render_template('predict.html', active_page='predict', patient_id=patient_id, form_data=form_data, error_message=err), 400

    # Evaluate prediction
    eval_result = evaluate_patient_prediction(
        fpg=fpg, hba1c=hba1c, ogtt=ogtt, rpg=rpg,
        insulin=insulin, cholesterol=cholesterol, triglycerides=triglycerides,
        model_suite=model_suite
    )

    if eval_result['status'] == 'insufficient':
        return render_template(
            'predict.html',
            active_page='predict',
            patient_id=patient_id,
            form_data=form_data,
            error_message=eval_result['error_message']
        ), 400

    # Save record in SQLite
    record_id = save_patient_record(
        patient_id=patient_id,
        patient_name=patient_name,
        age=age,
        gender="Not specified",
        pregnancies=0.0,
        fpg=fpg,
        hba1c=hba1c,
        ogtt=ogtt,
        rpg=rpg,
        insulin=insulin,
        cholesterol=cholesterol,
        triglycerides=triglycerides,
        bmi=None,
        evaluated_tests=eval_result['evaluated_tests'],
        prediction=eval_result['prediction'],
        is_diabetes=eval_result['is_diabetes'],
        prob_diabetes=eval_result['prob_diabetes'],
        prob_no_diabetes=eval_result['prob_no_diabetes']
    )

    return redirect(url_for('result_page', record_id=record_id))

@app.route('/result/<record_id>')
def result_page(record_id):
    """Page 3: Prediction Result Page with Submitted Medical Tests and Units"""
    record = get_patient_record(record_id)
    if not record:
        flash("Patient record not found. Please start a new prediction.", "error")
        return redirect(url_for('predict'))

    submitted_tests = []
    test_configs = [
        ('fpg', 'Fasting Blood Glucose (FPG)', 'mg/dL'),
        ('hba1c', 'Glycated Hemoglobin (HbA1c)', '%'),
        ('ogtt', '2-Hour OGTT Glucose', 'mg/dL'),
        ('rpg', 'Random Blood Glucose (RPG)', 'mg/dL'),
        ('insulin', 'Fasting Plasma Insulin', 'µIU/mL'),
        ('cholesterol', 'Total Cholesterol', 'mg/dL'),
        ('triglycerides', 'Triglycerides', 'mg/dL')
    ]

    for key, label, unit in test_configs:
        val = record.get(key)
        if val is not None:
            submitted_tests.append({
                'label': label,
                'val': val,
                'unit': unit
            })

    return render_template(
        'result.html',
        active_page='predict',
        record=record,
        submitted_tests=submitted_tests
    )

@app.route('/records')
def patient_records():
    """Page 4: Patient Records Management"""
    search_query = request.args.get('search', '').strip()
    status_filter = request.args.get('status', '').strip()
    sort_by = request.args.get('sort', 'date_desc').strip()

    records = get_all_patient_records(
        search_query=search_query,
        status_filter=status_filter,
        sort_by=sort_by
    )
    stats = get_patient_stats()

    return render_template(
        'records.html',
        active_page='records',
        records=records,
        stats=stats,
        search_query=search_query,
        status_filter=status_filter,
        sort_by=sort_by
    )

@app.route('/records/export')
def export_records_csv():
    """Export patient records to CSV with the 7 medical tests."""
    records = get_all_patient_records(sort_by='date_desc')
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'Patient ID',
        'Patient Name',
        'Age',
        'Fasting Blood Glucose (mg/dL)',
        'HbA1c (%)',
        '2-Hour OGTT (mg/dL)',
        'Random Blood Glucose (mg/dL)',
        'Fasting Plasma Insulin (µIU/mL)',
        'Total Cholesterol (mg/dL)',
        'Triglycerides (mg/dL)',
        'Evaluated Tests',
        'Predicted Outcome',
        'Diabetes Risk (%)',
        'Non-Diabetic Likelihood (%)',
        'Date Recorded'
    ])

    for r in records:
        writer.writerow([
            r['patient_id'],
            r.get('patient_name', ''),
            int(r['age']) if r.get('age') else '',
            r.get('fpg') if r.get('fpg') is not None else '',
            r.get('hba1c') if r.get('hba1c') is not None else '',
            r.get('ogtt') if r.get('ogtt') is not None else '',
            r.get('rpg') if r.get('rpg') is not None else '',
            r.get('insulin') if r.get('insulin') is not None else '',
            r.get('cholesterol') if r.get('cholesterol') is not None else '',
            r.get('triglycerides') if r.get('triglycerides') is not None else '',
            r.get('evaluated_tests', ''),
            r['prediction'],
            f"{r['prob_diabetes']}%",
            f"{r['prob_no_diabetes']}%",
            r['created_at']
        ])

    csv_data = output.getvalue()
    return Response(
        csv_data,
        mimetype='text/csv',
        headers={"Content-Disposition": "attachment; filename=medimind_patient_records.csv"}
    )

@app.route('/patient/<record_id>')
def patient_report(record_id):
    """Page 5: Individual Patient Printable Diagnostic Report"""
    record = get_patient_record(record_id)
    if not record:
        flash("Patient diagnostic record not found.", "error")
        return redirect(url_for('patient_records'))

    submitted_tests = []
    test_configs = [
        ('fpg', 'Fasting Blood Glucose (FPG)', 'mg/dL'),
        ('hba1c', 'Glycated Hemoglobin (HbA1c)', '%'),
        ('ogtt', '2-Hour OGTT Glucose', 'mg/dL'),
        ('rpg', 'Random Blood Glucose (RPG)', 'mg/dL'),
        ('insulin', 'Fasting Plasma Insulin', 'µIU/mL'),
        ('cholesterol', 'Total Cholesterol', 'mg/dL'),
        ('triglycerides', 'Triglycerides', 'mg/dL')
    ]

    for key, label, unit in test_configs:
        val = record.get(key)
        if val is not None:
            submitted_tests.append({
                'label': label,
                'val': val,
                'unit': unit
            })

    return render_template(
        'report.html',
        active_page='records',
        record=record,
        submitted_tests=submitted_tests
    )

@app.route('/records/delete/<record_id>', methods=['POST'])
def delete_record(record_id):
    """Delete a patient record from SQLite."""
    success = delete_patient_record(record_id)
    if success:
        flash(f"Patient record #{record_id} was successfully deleted.", "success")
    else:
        flash("Failed to delete patient record.", "error")
    return redirect(url_for('patient_records'))

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='127.0.0.1', port=port, debug=True)
