# MediMind Models Directory

This directory stores serialized model artifacts and preprocessing pipelines saved via `joblib`.

### Expected Artifacts:
- `multinomial_model.joblib`: The complete fitted pipeline containing feature transformers (imputation, encoding, scaling) and the Multinomial Logistic Regression estimator.
- `model_metrics.json`: Genuine held-out test evaluation metrics (accuracy, macro/weighted precision, recall, F1-scores, confusion matrix, and class names).
