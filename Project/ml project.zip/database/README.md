# MediMind Database Directory

This directory stores the SQLite database file (`medimind.db`) used for logging demonstration predictions and audit history.

### Privacy & Schema:
- Stores timestamp, predicted disease category, probability confidence vector, and input features.
- Does NOT store personally identifiable information (PII).
- Supports search, filtering, sorting, CSV export, and deletion.
