# MediMind — Multi-class Disease Diagnosis Using Multinomial Logistic Regression

> **Smarter Insights. Better Health.**

MediMind is an educational and demonstrative healthcare machine learning web platform built with Python Flask, scikit-learn, Bootstrap 5, and SQLite. It provides a transparent, interpretable multi-class diagnostic framework powered by Multinomial Logistic Regression.

---

## 🎨 Design System & Palette

- **Lavender:** `#E6DDF5`
- **Soft Peach:** `#F8DCD2`
- **Blush Pink:** `#F5E5EB`
- **Cream:** `#FFF9F5`
- **Dark Purple:** `#493B59`
- **White:** `#FFFFFF`

---

## 📂 Project Structure

```text
medimind/
├── app.py                  # Flask web server and routing
├── train_model.py          # Machine learning model training script (when dataset provided)
├── requirements.txt        # Python library dependencies
├── README.md               # Project documentation
├── .env.example            # Environment variables template
├── data/                   # Dataset directory
│   └── README.md
├── models/                 # Serialized joblib pipelines & metrics
│   └── README.md
├── database/               # SQLite database directory
│   └── README.md
├── templates/              # Jinja2 HTML templates
│   ├── base.html           # Master layout (nav, footer, disclaimer)
│   ├── index.html          # Page 1: Home / Dashboard
│   ├── placeholder.html    # Staging template for multi-page development
│   ├── predict.html        # Page 2: Patient Input (Next step)
│   ├── results.html        # Page 3: Prediction Results (Next step)
│   ├── analytics.html      # Page 4: Model Analytics (Next step)
│   ├── history.html        # Page 5: Prediction History (Next step)
│   ├── model_info.html     # Page 6: Model Information (Next step)
│   └── about.html          # Page 7: About MediMind (Next step)
├── static/
│   ├── css/
│   │   └── style.css       # Custom pastel design system & typography
│   ├── js/
│   │   ├── main.js         # Interactive UI handlers & navbar
│   │   └── analytics.js    # Chart.js visualization scripts
│   └── images/             # Visual assets & icons
└── tests/
    ├── test_routes.py      # Route integration tests
    └── test_model.py       # Model validation tests
```

---

## 🚀 Quick Start Guide (Windows PowerShell)

### 1. Navigate to the project directory:
```powershell
cd "c:\Users\teja\OneDrive\Documents\Manchine learning\medimind"
```

### 2. Create and activate a Python virtual environment:
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 3. Install dependencies:
```powershell
pip install -r requirements.txt
```

### 4. Run the Flask development server:
```powershell
python app.py
```

### 5. Open your browser:
Visit [http://127.0.0.1:5000](http://127.0.0.1:5000)

### 6. Run test suite:
```powershell
pytest
```

---

## ⚠️ Medical Disclaimer
Predictions provided by this software are produced by an educational machine learning demonstration. They are **not** clinically validated diagnoses and must **not** replace the judgment of licensed medical practitioners.
