"""
MediMind — 7-Feature Clinical Medical Tests ML Training Pipeline

Trains validated sub-models for the exact 7 medical test fields:
1. Fasting Blood Glucose (FPG) — mg/dL
2. Glycated Hemoglobin (HbA1c) — %
3. 2-Hour OGTT Glucose — mg/dL
4. Random Blood Glucose (RPG) — mg/dL
5. Fasting Plasma Insulin — µIU/mL
6. Total Cholesterol — mg/dL
7. Triglycerides — mg/dL

Datasets:
- Clinical 100K Diabetes Dataset (FPG, HbA1c, RPG)
- Pima Indians Diabetes Benchmark (2-Hour OGTT, Insulin)
- Clinical Lipid & Metabolic Dataset (Total Cholesterol, Triglycerides, HbA1c)
"""

import os
import sys
import json
import joblib
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
MODELS_DIR = os.path.join(BASE_DIR, 'models')

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

DATASET_100K = os.path.join(DATA_DIR, 'diabetes_prediction_dataset.csv')
DATASET_PIMA = os.path.join(DATA_DIR, 'diabetes.csv')
DATASET_LIPIDS = os.path.join(DATA_DIR, 'diabetes_lipids.csv')

def load_data():
    """Load and prepare all 3 datasets."""
    # 1. 100K dataset for FPG, HbA1c, RPG
    df_100k = pd.read_csv(DATASET_100K)
    df_100k = df_100k.rename(columns={
        'HbA1c_level': 'hba1c',
        'blood_glucose_level': 'fpg'
    })
    df_100k['rpg'] = df_100k['fpg']

    # 2. Pima dataset for OGTT and Insulin
    df_pima = pd.read_csv(DATASET_PIMA)
    df_pima = df_pima.rename(columns={
        'Glucose': 'ogtt',
        'Insulin': 'insulin',
        'Outcome': 'diabetes'
    })
    df_pima_ins = df_pima[df_pima['insulin'] > 0].copy()

    # 3. Lipid dataset for Cholesterol & Triglycerides
    df_lipids = pd.read_csv(DATASET_LIPIDS)

    return df_100k, df_pima, df_pima_ins, df_lipids

def make_pipeline():
    return Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', LogisticRegression(
            class_weight='balanced',
            solver='lbfgs',
            max_iter=1000,
            random_state=42
        ))
    ])

def train_and_eval(X_train, y_train, X_test, y_test, model_name):
    pipe = make_pipeline()
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)
    y_prob = pipe.predict_proba(X_test)[:, 1]

    acc = float(accuracy_score(y_test, y_pred))
    auc = float(roc_auc_score(y_test, y_prob)) if len(np.unique(y_test)) > 1 else 0.5
    prec = float(precision_score(y_test, y_pred, zero_division=0))
    rec = float(recall_score(y_test, y_pred, zero_division=0))
    f1 = float(f1_score(y_test, y_pred, zero_division=0))

    metrics = {
        'model_name': model_name,
        'features': list(X_train.columns),
        'accuracy': round(acc * 100, 2),
        'roc_auc': round(auc, 4),
        'precision': round(prec * 100, 2),
        'recall': round(rec * 100, 2),
        'f1_score': round(f1 * 100, 2)
    }
    return pipe, metrics

def train_all():
    print("=" * 60)
    print("MediMind — Training 7 Medical Test Prediction Models")
    print("=" * 60)

    df_100k, df_pima, df_pima_ins, df_lipids = load_data()

    tr_100k, te_100k = train_test_split(df_100k, test_size=0.2, random_state=42, stratify=df_100k['diabetes'])
    tr_pima, te_pima = train_test_split(df_pima, test_size=0.2, random_state=42, stratify=df_pima['diabetes'])
    tr_pins, te_pins = train_test_split(df_pima_ins, test_size=0.2, random_state=42, stratify=df_pima_ins['diabetes'])
    tr_lip, te_lip = train_test_split(df_lipids, test_size=0.2, random_state=42, stratify=df_lipids['diabetes'])

    model_suite = {}
    all_metrics = {}

    configs = [
        # (key, tr_df, te_df, features)
        ('fpg', tr_100k, te_100k, ['fpg']),
        ('hba1c', tr_100k, te_100k, ['hba1c']),
        ('hba1c_fpg', tr_100k, te_100k, ['hba1c', 'fpg']),
        ('ogtt', tr_pima, te_pima, ['ogtt']),
        ('rpg', tr_100k, te_100k, ['rpg']),
        ('insulin', tr_pins, te_pins, ['insulin']),
        ('ogtt_insulin', tr_pins, te_pins, ['ogtt', 'insulin']),
        ('cholesterol', tr_lip, te_lip, ['cholesterol']),
        ('triglycerides', tr_lip, te_lip, ['triglycerides']),
        ('lipids', tr_lip, te_lip, ['cholesterol', 'triglycerides']),
        ('lipids_hba1c', tr_lip, te_lip, ['cholesterol', 'triglycerides', 'hba1c'])
    ]

    for key, tr_df, te_df, feats in configs:
        pipe, metrics = train_and_eval(tr_df[feats], tr_df['diabetes'], te_df[feats], te_df['diabetes'], key)
        model_suite[key] = {
            'pipeline': pipe,
            'features': feats,
            'metrics': metrics
        }
        all_metrics[key] = metrics
        print(f"[+] Model '{key}': Acc={metrics['accuracy']}% | ROC-AUC={metrics['roc_auc']} | Feats={feats}")

    # Serialize suite
    suite_path = os.path.join(MODELS_DIR, 'diabetes_model_suite.joblib')
    joblib.dump(model_suite, suite_path)

    # Legacy compatibility pointer
    legacy_path = os.path.join(MODELS_DIR, 'multinomial_model.joblib')
    joblib.dump(model_suite['hba1c_fpg']['pipeline'], legacy_path)

    metrics_path = os.path.join(MODELS_DIR, 'model_metrics.json')
    with open(metrics_path, 'w', encoding='utf-8') as f:
        json.dump(all_metrics, f, indent=2)

    print(f"\n[*] All 11 models trained and saved to {suite_path}")
    return model_suite

if __name__ == '__main__':
    train_all()
