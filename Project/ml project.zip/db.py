"""
MediMind — SQLite Database Manager
Manages persistent patient records, clinical medical test results,
adaptive ML predictions, live statistics, and CSV export.
"""

import os
import sqlite3
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_DIR = os.path.join(BASE_DIR, 'database')
DB_PATH = os.path.join(DATABASE_DIR, 'medimind.db')

os.makedirs(DATABASE_DIR, exist_ok=True)

def get_db_connection():
    """Create and return a database connection with dictionary-like row access."""
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize or upgrade the SQLite schema for multi-test patient records."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='patient_records'")
    table_info = cursor.fetchone()

    if table_info and ('bmi REAL NOT NULL' in table_info[0] or 'glucose REAL NOT NULL' in table_info[0]):
        # Safely migrate existing table to allow NULL for optional tests like BMI
        cursor.execute("ALTER TABLE patient_records RENAME TO patient_records_legacy")
        cursor.execute("""
            CREATE TABLE patient_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id TEXT UNIQUE NOT NULL,
                patient_name TEXT NOT NULL,
                age REAL NOT NULL,
                gender TEXT NOT NULL,
                pregnancies REAL DEFAULT 0,
                fpg REAL DEFAULT NULL,
                hba1c REAL DEFAULT NULL,
                ogtt REAL DEFAULT NULL,
                rpg REAL DEFAULT NULL,
                bmi REAL DEFAULT NULL,
                glucose REAL DEFAULT 0,
                blood_pressure REAL DEFAULT 0,
                skin_thickness REAL DEFAULT 0,
                insulin REAL DEFAULT 0,
                diabetes_pedigree_function REAL DEFAULT 0,
                evaluated_tests TEXT DEFAULT '',
                prediction TEXT NOT NULL,
                is_diabetes INTEGER NOT NULL,
                prob_diabetes REAL NOT NULL,
                prob_no_diabetes REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        cursor.execute("""
            INSERT OR IGNORE INTO patient_records (
                id, patient_id, patient_name, age, gender, pregnancies,
                bmi, glucose, prediction, is_diabetes, prob_diabetes, prob_no_diabetes, created_at
            )
            SELECT id, patient_id, patient_name, age, gender, pregnancies,
                   bmi, glucose, prediction, is_diabetes, prob_diabetes, prob_no_diabetes, created_at
            FROM patient_records_legacy
        """)
        cursor.execute("DROP TABLE patient_records_legacy")
    else:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS patient_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id TEXT UNIQUE NOT NULL,
                patient_name TEXT NOT NULL,
                age REAL NOT NULL,
                gender TEXT NOT NULL,
                pregnancies REAL DEFAULT 0,
                fpg REAL DEFAULT NULL,
                hba1c REAL DEFAULT NULL,
                ogtt REAL DEFAULT NULL,
                rpg REAL DEFAULT NULL,
                bmi REAL DEFAULT NULL,
                glucose REAL DEFAULT 0,
                blood_pressure REAL DEFAULT 0,
                skin_thickness REAL DEFAULT 0,
                insulin REAL DEFAULT 0,
                diabetes_pedigree_function REAL DEFAULT 0,
                evaluated_tests TEXT DEFAULT '',
                prediction TEXT NOT NULL,
                is_diabetes INTEGER NOT NULL,
                prob_diabetes REAL NOT NULL,
                prob_no_diabetes REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

    # Ensure all required new columns exist
    cursor.execute("PRAGMA table_info(patient_records)")
    existing_cols = [row[1] for row in cursor.fetchall()]

    new_columns = {
        'fpg': 'REAL DEFAULT NULL',
        'hba1c': 'REAL DEFAULT NULL',
        'ogtt': 'REAL DEFAULT NULL',
        'rpg': 'REAL DEFAULT NULL',
        'insulin': 'REAL DEFAULT NULL',
        'cholesterol': 'REAL DEFAULT NULL',
        'triglycerides': 'REAL DEFAULT NULL',
        'evaluated_tests': 'TEXT DEFAULT ""'
    }

    for col_name, col_def in new_columns.items():
        if col_name not in existing_cols:
            cursor.execute(f"ALTER TABLE patient_records ADD COLUMN {col_name} {col_def}")

    conn.commit()
    conn.close()

def save_patient_record(patient_id, patient_name=None, age=0, gender="Not specified", pregnancies=0.0,
                        fpg=None, hba1c=None, ogtt=None, rpg=None, insulin=None,
                        cholesterol=None, triglycerides=None, bmi=None,
                        evaluated_tests="", prediction="", is_diabetes=False,
                        prob_diabetes=0.0, prob_no_diabetes=100.0, glucose=None):
    """
    Insert a patient diagnostic record with medical test results into SQLite.
    Missing test results are saved as NULL without inventing values.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if not patient_name or not patient_name.strip():
        patient_name = f"Patient {patient_id}"

    # If legacy glucose is not explicitly passed, use the primary available glucose value
    if glucose is None:
        glucose = fpg if fpg is not None else (ogtt if ogtt is not None else (rpg if rpg is not None else 0.0))

    cursor.execute("""
        INSERT INTO patient_records (
            patient_id, patient_name, age, gender, pregnancies,
            fpg, hba1c, ogtt, rpg, insulin, cholesterol, triglycerides, bmi, glucose,
            blood_pressure, skin_thickness, diabetes_pedigree_function,
            evaluated_tests, prediction, is_diabetes, prob_diabetes, prob_no_diabetes,
            created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?, ?, ?, ?)
    """, (
        patient_id,
        patient_name.strip(),
        float(age) if age is not None else 0.0,
        str(gender).strip() if gender else "Not specified",
        float(pregnancies) if pregnancies is not None else 0.0,
        float(fpg) if fpg is not None else None,
        float(hba1c) if hba1c is not None else None,
        float(ogtt) if ogtt is not None else None,
        float(rpg) if rpg is not None else None,
        float(insulin) if insulin is not None else None,
        float(cholesterol) if cholesterol is not None else None,
        float(triglycerides) if triglycerides is not None else None,
        float(bmi) if bmi is not None else None,
        float(glucose),
        evaluated_tests.strip(),
        prediction,
        1 if is_diabetes else 0,
        float(prob_diabetes),
        float(prob_no_diabetes),
        created_at
    ))
    record_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return record_id

def get_patient_record(record_identifier):
    """
    Fetch a patient record by database ID (integer) or unique patient_id string.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    if str(record_identifier).isdigit():
        cursor.execute("SELECT * FROM patient_records WHERE id = ? OR patient_id = ?", (int(record_identifier), str(record_identifier)))
    else:
        cursor.execute("SELECT * FROM patient_records WHERE patient_id = ?", (str(record_identifier),))

    row = cursor.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None

def get_patient_stats():
    """
    Calculate live counts directly from SQLite:
    - Total Patients
    - Diabetes Predicted
    - Diabetes Not Predicted
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) AS total FROM patient_records")
    total = cursor.fetchone()['total']

    cursor.execute("SELECT COUNT(*) AS diabetes FROM patient_records WHERE is_diabetes = 1")
    diabetes_count = cursor.fetchone()['diabetes']

    cursor.execute("SELECT COUNT(*) AS no_diabetes FROM patient_records WHERE is_diabetes = 0")
    no_diabetes_count = cursor.fetchone()['no_diabetes']

    conn.close()
    return {
        'total': total,
        'diabetes_predicted': diabetes_count,
        'diabetes_not_predicted': no_diabetes_count
    }

def get_all_patient_records(search_query=None, status_filter=None, sort_by='date_desc'):
    """
    Fetch records with search (by name or patient_id), status filter, and sorting.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM patient_records WHERE 1=1"
    params = []

    if search_query:
        q = f"%{search_query.strip()}%"
        query += " AND (patient_name LIKE ? OR patient_id LIKE ?)"
        params.extend([q, q])

    if status_filter:
        if status_filter.lower() in ['diabetes', 'predicted', '1']:
            query += " AND is_diabetes = 1"
        elif status_filter.lower() in ['no_diabetes', 'not_predicted', '0']:
            query += " AND is_diabetes = 0"

    # Sorting options
    if sort_by == 'date_asc':
        query += " ORDER BY id ASC"
    elif sort_by == 'name_asc':
        query += " ORDER BY LOWER(patient_name) ASC"
    elif sort_by == 'name_desc':
        query += " ORDER BY LOWER(patient_name) DESC"
    else:  # default 'date_desc'
        query += " ORDER BY id DESC"

    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def delete_patient_record(record_identifier):
    """Delete a single patient record by ID or patient_id."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if str(record_identifier).isdigit():
        cursor.execute("DELETE FROM patient_records WHERE id = ? OR patient_id = ?", (int(record_identifier), str(record_identifier)))
    else:
        cursor.execute("DELETE FROM patient_records WHERE patient_id = ?", (str(record_identifier),))
    rows_affected = cursor.rowcount
    conn.commit()
    conn.close()
    return rows_affected > 0

def clear_all_patient_records():
    """Delete all records from SQLite."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM patient_records")
    conn.commit()
    conn.close()
